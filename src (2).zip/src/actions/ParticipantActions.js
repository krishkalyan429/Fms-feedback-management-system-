// import {PARTICIPANT_ADD,PARTICIPANT_UPDATE,PARTICIPANT_DELETE,PARTICIPANT_SHOW,PARTICIPANT_SHOW_ALL, PARTICIPANT_REDIRECT_TO_UPDATE, PARTICIPANT_DISPLAY_MESSAGE} from "../actionTypes/PARTICIPANTActionTypes";


// export function _showAParticipant(participant = {},processing = false,message = ""){
//     return {
//         type : PARTICIPANT_SHOW,
//         participant,
//         processing,
//         message
//     }
// }

// export function _showAllParticipants(participantList = [],message = ""){
//     return {
//         type : PARTICIPANT_SHOW_ALL,
//         participantList : participantList,
//         message : message
//     }
// }


// export function _participantRedirectToUpdate(value = true,redirectionId = 0){
//     return {
//         type : PARTICIPANT_REDIRECT_TO_UPDATE,
//         value: value,
//         redirectionId:redirectionId
//     }
// }

// export function _updateParticipant(participant,message){
//     return {
//         type : PARTICIPANT_UPDATE,
//         participant,
//         message
//     }
// }

// export function _deleteParticipant(id) {
//     return {
//         type : PARTICIPANT_DELETE,
//         id : id
//     }
// }


// export function _addParticipant(participant,message,redirectToShow) {
//     return {
//         type : PARTICIPANT_ADD,
//         participant : participant,
//         message : message,
//         redirectToShow : redirectToShow
//     }
// }


// export function _displayMessage(message) {
//     return {
//         type : PARTICIPANT_DISPLAY_MESSAGE,
//         message : message
//     }
// }